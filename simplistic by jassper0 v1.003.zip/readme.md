## Simplistic by jassper0

<a href="https://osuck.link/redirect/https://files.osuck.link/tosu/simplistic by jassper0 v1.003.zip" target="_blank"><img height="35" src="https://img.shields.io/badge/Download_PP_Counter-67A564?style=for-the-badge&logo=cloud&logoColor=white" /></a>  <a href="https://github.com/jassper0" target="_blank"><img height="35" src="https://img.shields.io/badge/github-000000?style=for-the-badge&logo=github&logoColor=white" /></a>  

|||
| ------------- | ------------- |
| For | ingame, obs-overlay |
| Compatible with | gosu, tosu |
| Size |  750x250 |


<img src="/.github/images/simplistic by jassper0.jpg" /> <img src="/.github/gifs/simplistic by jassper0.gif" /> 
